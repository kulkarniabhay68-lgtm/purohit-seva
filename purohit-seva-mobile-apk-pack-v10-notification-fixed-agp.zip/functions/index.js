const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');

admin.initializeApp();

const TOPIC = 'purohit_seva_updates';
const WATCHED = new Set(['settings', 'aarti', 'muhurats', 'stotra', 'shanka', 'youtube']);

function stable(value) {
  try { return JSON.stringify(value ?? null); } catch (_) { return ''; }
}

function labelFor(collectionId, data) {
  if (collectionId === 'settings') return 'वेबसाईट अपडेट';
  const name = data?.title || data?.name || data?.heading || data?.puja || '';
  const map = {
    aarti: 'आरतीमध्ये नवीन अपडेट',
    muhurats: 'शुभ मुहूर्त अपडेट',
    stotra: 'स्तोत्रामध्ये नवीन अपडेट',
    shanka: 'शंका-समाधानामध्ये नवीन अपडेट',
    youtube: 'नवीन व्हिडिओ अपडेट'
  };
  return name ? `${map[collectionId] || 'नवीन अपडेट'}: ${name}` : (map[collectionId] || 'पुरोहित सेवा अपडेट');
}

exports.notifyPurohitSevaUpdate = onDocumentWritten(
  { document: '{collectionId}/{documentId}', region: 'asia-south1' },
  async (event) => {
    const { collectionId } = event.params;
    if (!WATCHED.has(collectionId)) return null;

    const before = event.data?.before?.data();
    const after = event.data?.after?.data();
    if (!after) return null;
    if (stable(before) === stable(after)) return null;
    if (after.published === false) return null;

    const title = labelFor(collectionId, after);
    const body = collectionId === 'settings'
      ? 'पुरोहित सेवा वेबसाइटवर नवीन माहिती उपलब्ध आहे.'
      : 'पुरोहित सेवा मध्ये नवीन माहिती उपलब्ध आहे.';

    await admin.messaging().send({
      topic: TOPIC,
      notification: { title, body },
      data: {
        collection: String(collectionId),
        documentId: String(event.params.documentId),
        url: 'https://purohit-seva-five.vercel.app/'
      },
      android: {
        notification: {
          channelId: 'purohit_seva_updates',
          sound: 'default'
        }
      }
    });
    return null;
  }
);
