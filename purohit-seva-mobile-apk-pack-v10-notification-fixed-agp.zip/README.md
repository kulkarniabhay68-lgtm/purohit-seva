Purohit Seva — Android APK V10 Notification Fixed

This package fixes the Android build error caused by androidx.core:core:1.17.0 requiring Android Gradle Plugin 8.9.1+.

Build versions:
- Android Gradle Plugin: 8.9.1
- Gradle: 8.11.1
- Java: 17
- compileSdk/targetSdk: 35
- App versionCode: 11, versionName: 1.1.1
- Firebase Messaging enabled
- Topic: purohit_seva_updates
- Notifications permission requested on Android 13+

GitHub Actions:
1. Upload the contents of this package to the repository root.
2. Keep .github/workflows/build-apk.yml at that exact path.
3. Run Actions → Build Purohit Seva APK V10 Notification Fixed → Run workflow.
4. Download the artifact named purohit-seva-v10-notification-debug-apk.

Firebase automatic notifications:
The functions folder is included for the Firestore-triggered notification function. Deploy it separately with Firebase CLI when required.
