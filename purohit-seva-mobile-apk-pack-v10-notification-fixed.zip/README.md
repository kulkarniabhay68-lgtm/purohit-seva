# Purohit Seva V9 — Live Website + Push Notifications

This package is prepared to:
- open the live Purohit Seva website in the Android app
- subscribe installed Android devices to the `purohit_seva_updates` FCM topic
- show push notifications in the background/closed app
- trigger notifications automatically from Firestore changes via Firebase Cloud Functions

## One required Firebase step
Firebase requires a native Android app registration for package `com.purohitseva.app` and its `google-services.json` file. Put that file at:

`purohit-seva-android/app/google-services.json`

Do not rename it.

Then the GitHub Actions build can create the APK.

## Automatic notifications
Deploy the included `functions/` folder to the same Firebase project. It watches the public content collections used by the site and sends a notification to topic `purohit_seva_updates` when published data changes.

The Cloud Function is server-side; the Android app never contains a server key/private key.
